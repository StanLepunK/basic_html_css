### Your challenge
- At large screens (about 750px), this section should have a minimum height of 100vh and the content centered vertically
- The images should have a width of 100%, and a height of 15em. 
- Fix the images so that they don’t stretch when given their height.
