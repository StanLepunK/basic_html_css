### Your challenge
- Everything in this challenge is only for 750px and bigger
- You cannot touch the HTML
- Change the background color of ‘.article’ to green
- Change all the text to be #252525
