### Your challenge
- At small screens, this section should have a white background
- Above 750px, it should have a background of #252525 and white text
- Above 750px, the .container in this section should max out at 1200px
- Above 750px, the three images should go next to one another, with a width of 28%, and spaced out equally
